const AWS = require("aws-sdk");
const dynamodb = new AWS.DynamoDB.DocumentClient();
const tableName = process.env.DYNAMODB_TABLE;

module.exports.getTodos = async (event) => {
  try {
    const data = await dynamodb.scan({ TableName: tableName }).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(data.Items),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to fetch todos" }),
    };
  }
};

module.exports.createTodo = async (event) => {
  const { title, completed } = JSON.parse(event.body);
  const params = {
    TableName: tableName,
    Item: {
      id: Date.now().toString(),
      title,
      completed,
    },
  };

  try {
    await dynamodb.put(params).promise();
    return {
      statusCode: 201,
      body: JSON.stringify(params.Item),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Failed to create todo" }),
    };
  }
};
